import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
 
public class App extends Application {
    public static void main(String[] args) {
        launch(args);
    }
    
    @Override
    public void start(Stage primaryStage) {
        ControlCircle circle = new ControlCircle();
        primaryStage.setTitle("Exercise 15");
        Button lbt = new Button("Left");
        Button rbt = new Button("Right");
        Button ubt = new Button("Up");
        Button dbt = new Button("Down");
        rbt.setOnAction(e->{
            circle.right();
        });
        lbt.setOnAction(e-> {
            circle.left();
        });
        ubt.setOnAction(e-> {
            circle.up();
        });
        dbt.setOnAction(e-> {
            circle.down();
        });
        
        HBox root = new HBox(15);
        root.getChildren().addAll(lbt,rbt,ubt,dbt);
        BorderPane bPane = new BorderPane();
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(15,15,15,15));
        bPane.setBottom(root);
        bPane.setCenter(circle);
        primaryStage.setScene(new Scene(bPane, 300, 250));
        primaryStage.show();
    }
}