import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.scene.paint.Color;
public class ControlCircle extends Pane {
    public final double radius = 20;
    private double x = 100, y = 100;
    private double dx = 10, dy = 10;
    private Circle circle = new Circle(x,y,radius);
    public ControlCircle(){
        circle.setFill(Color.WHITE);
        circle.setStroke(Color.BLACK);
        getChildren().add(circle);
    }
    protected void left(){
        if (!(x< (radius+dx))){
            x-= dx;
            circle.setCenterX(x);
        }
    }
    protected void right(){
        if (!(x > getWidth() - radius-dx)){
            x+= dx;
            circle.setCenterX(x);
        }
    }
    protected void up(){
        if (!(y< radius+dy)){
            y-= dy;
            circle.setCenterY(y);
        }
    }
    protected void down(){
        if (!(y > getHeight() - radius-dy)){
            y+= dy;
            circle.setCenterY(y);
        }
    }
}