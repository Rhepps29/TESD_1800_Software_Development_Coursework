import java.io.*;

 
public class Pro17_3 {
    
    static void output() throws IOException{
        File file = new File("Exercise17_03.dat");
        boolean hi = false;
        if (file.exists()){
            hi = true;
        }
        try(
            DataOutputStream output = new DataOutputStream(new FileOutputStream(file, hi));
        ){
        for (int i = 0; i<100; i++){
            output.writeInt((int)(Math.random()*100));
        }}
    }
    static void input() throws IOException{
        int hi = 0;
        try(
            DataInputStream input = new DataInputStream(new FileInputStream("Exercise17_03.dat"));
        ){
            
            while (true){
                hi += input.readInt();
            }
        }catch (EOFException ex){
            System.out.println(hi);
        }
    }
    public static void main(String[] args) throws IOException {
        output();
        input();
    }
}