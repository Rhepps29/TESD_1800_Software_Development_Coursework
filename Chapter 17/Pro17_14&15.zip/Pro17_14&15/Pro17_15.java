import java.io.*;
import java.util.*;
public class Pro17_15{
    public static void main(String[] args) throws ClassNotFoundException, IOException{
        System.out.print("Enter input file name: ");
        Scanner base = new Scanner(System.in);
        File sourceFile = new File(base.next());
        if (!sourceFile.exists()){
            System.out.println("File does not exist");
            System.exit(0);
        }
        System.out.print("Enter output file name: ");
        File targetFile = new File(base.next());
        if (targetFile.exists()){
            System.out.println("File already exists");
            System.exit(0);
        }
        
        try(
            BufferedInputStream input = new BufferedInputStream(new FileInputStream(sourceFile));
            BufferedOutputStream output = new BufferedOutputStream(new FileOutputStream(targetFile));
        ){
            int r, numberOfBytesCopied = 0;
            
            while ((r = input.read()) != -1){
                output.write((byte)r-5);
                numberOfBytesCopied ++;
            }
            System.out.println(numberOfBytesCopied + " bytes decoded.");
            
            
        }
        
    }
}